// for cataegrious list
let selectfeild = document.getElementById("nav-selectfeild");
let select_text = document.getElementById("select-text");
let options = document.getElementsByClassName("list");
let list = document.getElementById("nav-list");
let navhide = document.getElementsByClassName("list");
// for side bar
const bar = document.querySelector("#bar");
const close = document.querySelector("#cross");
const nav = document.querySelector("#nav-acess");
// for shopping cart 
let iconcart = document.querySelector("#cart");
let cartTab = document.querySelector("#cart-tab");

// making categiory baar 
selectfeild.onclick =() => {
    list.classList.toggle("hide");
    
}
for( i of options){
    i.onclick = () => {
        list.classList.toggle("hide");
    }
}
//making side bar for mobile
if (bar){
    console.log("working");
    bar.addEventListener("click", () => {
        console.log("working");
        nav.classList.add('cart-show');
    })

}
if (cross){
    console.log("working");
    cross.addEventListener("click", () => {
        console.log("working");
        nav.classList.remove('active');
    })

}
// making shoping cart 

if (iconcart){
    
    iconcart.addEventListener("click", () => {
        cartTab.classList.add('cart-show');
    })

}
if (cross){
    cross.addEventListener("click", () => {
        console.log("working");
        nav.classList.remove('active');
    })

}
// making login form
loginBtn.addEventListener("click", () => {
    console.log("working login");
    login.style.left = "10%"
    Register.style.left = "450px"
    logBtn.style.left = "0px"
    
})
registerBtn.addEventListener("click", () => {
    console.log("working regis");
    login.style.left = "-450px"
    Register.style.left = "10%"
    logBtn.style.left = "110px"
})