// for login and register bar 
let login = document.querySelector("#login");
let Register = document.getElementById("Register");
let logBtn = document.getElementById("log-btn");
let loginBtn = document.getElementById("login-btn");
let registerBtn = document.getElementById("register-btn");
// making login form
loginBtn.addEventListener("click", () => {
    console.log("working login");
    login.style.left = "10%"
    Register.style.left = "450px"
    logBtn.style.left = "0px"
    
})
registerBtn.addEventListener("click", () => {
    console.log("working regis");
    login.style.left = "-450px"
    Register.style.left = "10%"
    logBtn.style.left = "110px"
})